package furhatos.app.socialClient.setting.chatgpt
import com.theokanning.openai.completion.chat.ChatCompletionRequest
import com.theokanning.openai.completion.chat.ChatMessage
import com.theokanning.openai.service.OpenAiService
import furhatos.app.socialClient.SocialClientSkill
import furhatos.flow.kotlin.DialogHistory
import furhatos.flow.kotlin.Furhat
import furhatos.gestures.Gesture
import furhatos.gestures.Gestures
import furhatos.gestures.Gestures.Blink
import furhatos.gestures.Gestures.BrowFrown
import furhatos.gestures.Gestures.BrowRaise
import furhatos.gestures.Gestures.ExpressAnger
import furhatos.gestures.Gestures.ExpressDisgust
import furhatos.gestures.Gestures.ExpressFear
import furhatos.gestures.Gestures.ExpressSad
import furhatos.gestures.Gestures.GazeAway
import furhatos.gestures.Gestures.Oh
import furhatos.gestures.Gestures.Surprise
import furhatos.gestures.Gestures.Thoughtful
import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.roundToLong


class ChatGPT(_apiKey: OpenAiService)
{
    var apiKey: OpenAiService
    var systemPrompt: String
    private var history: String
    private var emotion = ""
    private var response = ""

    constructor(_apiKey: OpenAiService, _systemPrompt: String) : this(_apiKey)
    {
        this.systemPrompt = _systemPrompt
        this.apiKey = _apiKey
    }

    init
    {
        this.apiKey = _apiKey
        this.systemPrompt = loadPrompt()
        this.history = ""
    }

    fun extractEmotion(answer: String): String
    {
        this.emotion = answer.substring(answer.indexOf("[") + 1, answer.indexOf("]"))
        println(this.emotion)
        this.response = answer.replace("[$emotion]", "")
        return this.response
    }

    fun getEmotion(): Gesture
    {
        var duration = calcAnswerDuration()

        /**
        return when (this.emotion) {
            "BrowFrown" -> BrowFrown()
            "BrowRaise" -> BrowRaise()
            "Oh" -> Oh()
            "GazeAway" -> GazeAway()
            "Surprise" -> Surprise()
            "Thoughtful" -> Thoughtful()
            "ExpressAnger" -> ExpressAnger()
            "ExpressFear" -> ExpressFear()
            "ExpressDisgust" -> ExpressDisgust()
            "ExpressSad" -> ExpressSad()
            else ->  Blink
        }
        */

        return when (this.emotion) {
            "BrowFrown" -> BrowFrown(duration=duration)
            "BrowRaise" -> BrowRaise(duration=duration)
            "Oh" -> Oh(duration=duration)
            "GazeAway" -> GazeAway(duration=duration)
            "Surprise" -> Surprise(duration=duration)
            "Thoughtful" -> Thoughtful(duration=duration)
            "ExpressAnger" -> ExpressAnger(duration=duration)
            "ExpressFear" -> ExpressFear(duration=duration)
            "ExpressDisgust" -> ExpressDisgust(duration=duration)
            "ExpressSad" -> ExpressSad(duration=duration)
            else ->  Blink
        }


        /**
        if (this.emotion == "BrowRaise")
        {
            println("Gesture: BrowRaise")
            return BrowRaise(duration = duration)
        }
        if (this.emotion == "BrowFrown")
        {
            println("Gesture: BrowFrown")
            return BrowFrown(duration = duration)
        }
        if (this.emotion == "Oh")
        {
            println("Gesture: Oh")
            return Oh(duration = duration)
        }
        if (this.emotion == "GazeAway")
        {
            println("Gesture: Gaze")
            return GazeAway(duration = duration)
        }
        if (this.emotion == "Surprise")
        {
            println("Gesture: Surprise")
            return Surprise(duration = duration)
        }
        if (this.emotion == "Thoughtful")
        {
            println("Gesture: Thoughtful")
            return Thoughtful(duration = duration)
        }
        if (this.emotion == "ExpressAnger")
        {
            println("Gesture: ExpressAnger")
            return ExpressAnger(duration = duration)
        }
        if (this.emotion == "ExpressFear")
        {
            println("Gesture: ExpressFear")
            return ExpressFear(duration = duration)
        }
        if (this.emotion == "ExpressDisgust")
        {
            println("Gesture: ExpressDisgust")
            return ExpressDisgust(duration = duration)
        }
        if (this.emotion == "ExpressSad")
        {
            println("Gesture: ExpressSad")
            return ExpressSad(duration = duration)
        }
        println("Gesture: Blink")
        return Blink(duration = duration)
        */
    }

    fun calcAnswerDuration(): Double
    {
        val wordsPerMinute = 140
        val wordsCount = this.response.split(" ").size
        println("WordCount: $wordsCount")

        return BigDecimal((wordsCount.toDouble() / wordsPerMinute * 60)).setScale(2, RoundingMode.HALF_EVEN).toDouble()
    }

    fun getResponse(): String
    {
        return this.response
    }

    fun getDialogCompletion(contextWindowSize: Int = 10): String?
    {

        val messages = mutableListOf(ChatMessage().apply { role = "system"; content = systemPrompt})


        Furhat.dialogHistory.all.takeLast(contextWindowSize).forEach {
            when (it)
            {
                is DialogHistory.ResponseItem ->
                    { messages.add(ChatMessage().apply { role = "user"; content = it.response.text }) }
                is DialogHistory.UtteranceItem ->
                    { messages.add(ChatMessage().apply { role = "assistant"; content = it.toText() }) }
                else -> null
            }
        }

        this.history += messages

        val completionRequest = ChatCompletionRequest.builder()
            .messages(messages)
            .model("gpt-4")
            .build()

        try
        {
            val completion = apiKey.createChatCompletion(completionRequest).choices.first().message.content
            println(extractEmotion(completion.trim()))
            return extractEmotion(completion.trim())
        } catch (e: Exception)
        {
            println("problem with connection to OpenAI\n ERROR: ${e.localizedMessage}")
        }

        return null
    }

    fun loadPrompt(): String
    {
        val prompt = SocialClientSkill::class.java.getResourceAsStream("/prompt.txt")

        return if (prompt.available() != 0) {
            prompt.bufferedReader().use { it.readText() }
        } else
            "File not found!"
    }

    fun toConsole()
    {
        println(this.history)
    }
}

// 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 - Uni
/** private apiKey = sk-proj-4ZrgPwD3KpwkkIieT95WT3BlbkFJ2g4mAK9BO1XMQR4uDXp8 */
val testExample = ChatGPT(_apiKey = OpenAiService("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"))






