# Skill
Template skill

## Description
This is a skill template, see [the docs](https://docs.furhat.io/skills/#the-contents-of-a-skill) for a breakdown of the content. 
For more example skills go to [our Github](https://github.com/FurhatRobotics/)

## Usage
Max number of users is set to: 2
Default interaction distance is set to: 1 m
No other specific requirements. 